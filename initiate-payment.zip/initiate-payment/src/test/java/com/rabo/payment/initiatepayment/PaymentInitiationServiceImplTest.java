package com.rabo.payment.initiatepayment;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;

import com.rabo.payment.initiatepayment.exception.PaymentServiceException;
import com.rabo.payment.initiatepayment.impl.PaymentInitiationServiceImpl;
import com.rabo.payment.initiatepayment.model.PaymentAcceptedResponse;
import com.rabo.payment.initiatepayment.model.PaymentInitiationRequest;

import junit.framework.Assert;

import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpHeaders;

@RunWith(PowerMockRunner.class)


public class PaymentInitiationServiceImplTest {

	@InjectMocks
	private PaymentInitiationServiceImpl paymentInitiationServiceImpl;

	@Before
	public void setUp() throws Exception {
		
	}
	
	@Test
	public void initiatePaymentTest() throws Exception {		
		
		Map<String, String> headers = new HashMap<>();
		headers.put("Signature", "123");
		headers.put("Signature-Certificate", "343432");
		PaymentAcceptedResponse paymentAcceptedResponse  = paymentInitiationServiceImpl.initiatePayment(preparePaymentInitiationRequest(), headers);
		Assert.assertNotNull(paymentAcceptedResponse);
	}
    
	@Test
    public void testPaymentServiceException() throws PaymentServiceException
    {
		PaymentAcceptedResponse paymentAcceptedResponse;
		try {
			Map<String, String> headers = new HashMap<>();
			headers.put("Signature", "123");
			headers.put("Signature-Certificate", "343432");
			paymentAcceptedResponse = paymentInitiationServiceImpl.initiatePayment(preparePaymentInitiationInvallidRequest(), headers);
			Assert.assertNotNull(paymentAcceptedResponse);
			
		} catch (PaymentServiceException e) {
			
		}			
    }


	
	
	/**
	 * Prepare PaymentInitiationRequest
	 * @return
	 */
	private PaymentInitiationRequest preparePaymentInitiationRequest() {
		PaymentInitiationRequest paymentInitiationRequest = new PaymentInitiationRequest();
		paymentInitiationRequest.setAmount("2");
		paymentInitiationRequest.setCreditorIBAN("NL94ABNA1008270121");
		paymentInitiationRequest.setDebtorIBAN("NL02RABO7134384551");
		paymentInitiationRequest.setCurrency("USD");
		paymentInitiationRequest.setEndToEndId("123");
		return paymentInitiationRequest;
	}
	
	private PaymentInitiationRequest preparePaymentInitiationInvallidRequest() {
		PaymentInitiationRequest paymentInitiationRequest = new PaymentInitiationRequest();
		paymentInitiationRequest.setAmount("2");
		paymentInitiationRequest.setCreditorIBAN("");
		paymentInitiationRequest.setDebtorIBAN("");
		paymentInitiationRequest.setCurrency("USD");
		paymentInitiationRequest.setEndToEndId("123");
		return paymentInitiationRequest;
	}

}
