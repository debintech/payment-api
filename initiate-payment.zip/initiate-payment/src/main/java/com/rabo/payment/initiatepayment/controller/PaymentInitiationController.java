package com.rabo.payment.initiatepayment.controller;

import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rabo.payment.initiatepayment.constants.PaymentConstant;
import com.rabo.payment.initiatepayment.exception.PaymentServiceException;
import com.rabo.payment.initiatepayment.interfaces.PaymentInitiationService;
import com.rabo.payment.initiatepayment.model.PaymentAcceptedResponse;
import com.rabo.payment.initiatepayment.model.PaymentInitiationRequest;
import com.rabo.payment.initiatepayment.model.PaymentRejectedResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping(PaymentConstant.V1)
public class PaymentInitiationController {
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(this.getClass());

	@Autowired
	PaymentInitiationService paymentInitiationService;

	@Operation(summary = "Initiate a payment", description = "This API receives a payment initiation request. The API validates the requ`est and returns transaction status with signature that the client can verify the response")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "The 201 response of the payment initiation endpoint", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = PaymentAcceptedResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "The 400 response of the payment initiation endpoint", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = PaymentRejectedResponse.class)) }),
			@ApiResponse(responseCode = "422", description = "The 422 response of the payment initiation endpoint", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = PaymentRejectedResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "The 500 response of the payment initiation endpoint", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = PaymentRejectedResponse.class)) }) })

	@PostMapping(PaymentConstant.INITIATE_PAYMENT)
	ResponseEntity<PaymentAcceptedResponse> intiatePayment(
			@RequestHeader Map<String, String> headers,
			@Valid @RequestBody PaymentInitiationRequest paymentInitiationRequest) throws PaymentServiceException {

		String methodName = "intiatePayment";
		LOGGER.info(this.getClass() + "::" + methodName);

		PaymentAcceptedResponse paymentAcceptedResponse = paymentInitiationService
				.initiatePayment(paymentInitiationRequest, headers);
		HttpHeaders header = new HttpHeaders();
		
		
		header.add("Signature", headers.get("signature"));
		header.add("Signature-Certificate", headers.get("signature-certificate"));
		return ResponseEntity.status(HttpStatus.CREATED).headers(header).body(paymentAcceptedResponse);

	}

}
