package com.rabo.payment.initiatepayment.interfaces;

import java.util.Map;

import com.rabo.payment.initiatepayment.exception.PaymentServiceException;
import com.rabo.payment.initiatepayment.model.PaymentAcceptedResponse;
import com.rabo.payment.initiatepayment.model.PaymentInitiationRequest;

public interface PaymentInitiationService {

	public PaymentAcceptedResponse initiatePayment(PaymentInitiationRequest paymentInitiationRequest,
			Map<String, String> headers) throws PaymentServiceException;

}
