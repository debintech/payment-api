package com.rabo.payment.initiatepayment.impl;

import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabo.payment.initiatepayment.constants.PaymentConstant;
import com.rabo.payment.initiatepayment.exception.PaymentServiceException;
import com.rabo.payment.initiatepayment.interfaces.PaymentInitiationService;
import com.rabo.payment.initiatepayment.model.ErrorReasonCode;
import com.rabo.payment.initiatepayment.model.PaymentAcceptedResponse;
import com.rabo.payment.initiatepayment.model.PaymentInitiationRequest;
import com.rabo.payment.initiatepayment.model.TransactionStatus;

@Service
public class PaymentInitiationServiceImpl implements PaymentInitiationService {

	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(this.getClass());

	/**
	 * This method used to initiate the payment and return the response with
	 * status and header
	 * 
	 * @throws Exception
	 */
	@Override
	public PaymentAcceptedResponse initiatePayment(PaymentInitiationRequest paymentInitiationRequest,
			Map<String, String> headers) throws PaymentServiceException {

		String methodName = "initiatePayment";
		LOGGER.info(this.getClass() + "::" + methodName);
		PaymentAcceptedResponse paymentAcceptedResponse = null;
		boolean isSigVerified = verifyIncomingCertificateSignatueWithRSA(paymentInitiationRequest, headers);

		if (isSigVerified) {
			paymentAcceptedResponse = new PaymentAcceptedResponse();

			if (isAmountLimitExceed(paymentInitiationRequest)) {
				throw new PaymentServiceException(ErrorReasonCode.LIMIT_EXCEEDED.toString());
			} else {
				paymentAcceptedResponse.setStatus(TransactionStatus.ACCEPTED);
				paymentAcceptedResponse.setPaymentId(UUID.randomUUID());
			}

		}

		return paymentAcceptedResponse;

	}

	/**
	 * This method is used to check if the given amount is exceeded or not
	 * 
	 * @param paymentInitiationRequest
	 * @return
	 * @throws Exception
	 */
	private boolean isAmountLimitExceed(PaymentInitiationRequest paymentInitiationRequest)
			throws PaymentServiceException {
		try {
			int sum = sumDebtorIBAN(paymentInitiationRequest.getDebtorIBAN());
			int length = paymentInitiationRequest.getDebtorIBAN().length();

			if ((Integer.parseInt(paymentInitiationRequest.getAmount()) > 0) && (sum % length == 0)) {
				return true;
			}

		} catch (Exception ex) {
			LOGGER.info(PaymentConstant.GENERAL_ERROR_MESSAGE);
			throw new PaymentServiceException(ErrorReasonCode.GENERAL_ERROR.toString());
		}

		return false;
	}

	/**
	 * This method is used to find the sum of the digits of the
	 * `DebtorAccountNumber`.
	 * 
	 * @param debtorIBAN
	 * @return
	 */
	public int sumDebtorIBAN(String debtorIBAN) {
		return debtorIBAN.chars().mapToObj(i -> (char) i).filter(Character::isDigit)
				.mapToInt(Character::getNumericValue).sum();
	}

	/**
	 * This is to verify the signature with RSA
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	boolean verifyIncomingCertificateSignatueWithRSA(PaymentInitiationRequest paymentInitiationRequest,
			Map<String, String> headers) throws PaymentServiceException {
		boolean isSigVerified = false;

		try {
			String XRequestId = (String) headers.get("x-request-id");
			String digest = digest(PaymentConstant.ALGORITHM_TYPE, paymentInitiationRequest);

			// PrivateKey ;
			KeyPair keyPair = generateRSAKeyPair();
			byte[] digestRequest = (XRequestId + digest).getBytes();

			// Create signature
			byte[] signature = computeSignatureSHA256WithRSA(keyPair.getPrivate(), digestRequest);

			// Verify the signature
			isSigVerified = verifyDigitalSignature(digestRequest, signature, keyPair.getPublic());
		} catch (Exception ex) {
			throw new PaymentServiceException(ErrorReasonCode.INVALID_SIGNATURE.toString());

		}

		return isSigVerified;

	}

	/**
	 * Create the digest of the payload Message digest is computed by applying
	 * hash function on the message
	 * 
	 * @param sha256
	 * @param paymentInitiationRequest
	 * @return
	 * @throws NoSuchAlgorithmException
	 */
	public String digest(String sha256, PaymentInitiationRequest paymentInitiationRequest)
			throws NoSuchAlgorithmException {
		// Creating the MessageDigest object

		String bodyText = asJsonString(paymentInitiationRequest);
		MessageDigest md = MessageDigest.getInstance(sha256);

		// Passing data to the created MessageDigest Object
		md.update(bodyText.getBytes());

		// Compute the message digest
		byte[] digest = md.digest();
		return PaymentConstant.ALGORITHM_TYPE + "=" + Base64.getEncoder().encodeToString(digest);

	}

	/**
	 * This is used to convert the object to json
	 * @param obj
	 * @return
	 */
	public String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * This is used to compute the actual signature SHA256 with RSA
	 * 
	 * @param key
	 * @param digestRequest
	 * @return
	 * @throws SignatureException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 */
	public byte[] computeSignatureSHA256WithRSA(PrivateKey key, byte[] digestRequest)
			throws SignatureException, NoSuchAlgorithmException, InvalidKeyException {

		Signature signature = Signature.getInstance(PaymentConstant.SIGNING_ALGORITHM);
		signature.initSign(key);
		signature.update(digestRequest);
		return signature.sign();

	}

	/**
	 * This is to verify the digital signature
	 * 
	 * @param input
	 * @param signatureToVerify
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public boolean verifyDigitalSignature(byte[] digestRequest, byte[] signatureToVerify, PublicKey key)
			throws Exception {
		Signature signature = Signature.getInstance(PaymentConstant.SIGNING_ALGORITHM);
		signature.initVerify(key);
		signature.update(digestRequest);
		return signature.verify(signatureToVerify);
	}

	/**
	 * This is used to Generating the asymmetric key pair using SecureRandom
	 * class functions and RSA algorithm.
	 * 
	 * @return
	 * @throws Exception
	 */
	public KeyPair generateRSAKeyPair() throws Exception {
		SecureRandom secureRandom = new SecureRandom();
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(PaymentConstant.RSA);
		keyPairGenerator.initialize(2048, secureRandom);
		return keyPairGenerator.generateKeyPair();
	}

}
