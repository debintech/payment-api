package com.rabo.payment.initiatepayment.exception;

public class PaymentServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9095737652449568046L;

	public PaymentServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PaymentServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
