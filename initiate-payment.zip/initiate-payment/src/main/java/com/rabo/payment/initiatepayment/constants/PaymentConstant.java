package com.rabo.payment.initiatepayment.constants;

public class PaymentConstant {
	
	public final static  String V1 = "/v1.0.0";
	public final static  String INITIATE_PAYMENT = "/initiate-payment";
	public final static  String INVALID_MESSAGE = "The request is invalid. Please provide correct value";
	public final static  String INTERNAL_SERVER_MESSAGE = "There is some internal server error";
	public final static  String  AFTER_COMPLETION_MESSAGE = "Request and Response is completed";
	public final static  String  GENERAL_ERROR_MESSAGE = "This is general error";
	public final static  String  AMOUNT_LIMIT_EXCEEDED_MESSAGE = "Amount limit exceeded";
	public final static  String  CERTIFICATION_UNKNOWN_MESSAGE = "Certification is un-known";
	public final static  String  INVALID_SIGNATURE_MESSAGE = "The given signature is invalid";
	public final static  String  CERTIFICATES_VERIFIED_MESSAGE = "The certificates is Accepted";
	public final static  String  CERTIFICATES_NOT_VERIFIED_MESSAGE = "The certificates is not verified";
	
	
	public final static  String  NO_SUCH_ALGORITHM_MESSAGE = "NoSuchAlgorithm is present";
	public final static  String  INVALIDKEY_MESSAGE = "The Key is invalid";
	
	// Signing Algorithm
	public static final String SIGNING_ALGORITHM = "SHA256withRSA";
	public static final String RSA = "RSA";
	public static final String ALGORITHM_TYPE = "SHA-256";

	
}
