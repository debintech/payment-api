package com.rabo.payment.initiatepayment.swagger;

//@Configuration
//@EnableSwagger2
public class SwaggerConfig123 {
    
  /*  public static final Contact DEFAULT_CONTACT = new Contact(
    	      "", "", "");
    	  
    	  public static final ApiInfo DEFAULT_API_INFO = new ApiInfo(
    	      "Payment initiation sandbox API", "Payment API Description", "1.0.0",
    	      "urn:tos", DEFAULT_CONTACT, 
    	      "Apache 2.0", "http://www.apache.org/licenses/LICENSE-2.0",Arrays.asList());

    	  private static final Set<String> DEFAULT_PRODUCES_AND_CONSUMES = 
    	      new HashSet<String>(Arrays.asList("application/json"));

    	  @Bean
    	  public Docket api() {
    	    return new Docket(DocumentationType.SWAGGER_2)
    	        .apiInfo(DEFAULT_API_INFO)
    	        .produces(DEFAULT_PRODUCES_AND_CONSUMES)
    	        .consumes(DEFAULT_PRODUCES_AND_CONSUMES);
    	  }
*/    
}
