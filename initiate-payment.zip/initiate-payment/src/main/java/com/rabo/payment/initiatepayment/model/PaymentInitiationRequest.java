package com.rabo.payment.initiatepayment.model;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * The payment initiation request model
 */

@Data
@Valid
public class PaymentInitiationRequest {

	@NotNull
	@NotBlank
	@Pattern(regexp = "[A-Z]{2}[0-9]{2}[a-zA-Z0-9]{1,30}", message = "INVALID_REQUEST")
	@JsonProperty("debtorIBAN")
	private String debtorIBAN;

	@NotNull
	@NotBlank
	@Pattern(regexp = "[A-Z]{2}[0-9]{2}[a-zA-Z0-9]{1,30}", message = "INVALID_REQUEST")
	@JsonProperty("creditorIBAN")
	private String creditorIBAN;

	@NotNull
	@NotBlank
	@Pattern(regexp = "-?[0-9]+(\\.[0-9]{1,3})?", message = "INVALID_REQUEST")
	@JsonProperty("amount")
	private String amount;

	@Pattern(regexp = "[A-Z]{3}", message = "INVALID_REQUEST")
	@JsonProperty("currency")
	private String currency;

	@JsonProperty("endToEndId")
	private String endToEndId;

}
