package com.rabo.payment.initiatepayment.model;

import com.fasterxml.jackson.annotation.JsonProperty;

//import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
public class PaymentRejectedResponse {
	@JsonProperty("status")
	private TransactionStatus status;

	@JsonProperty("reason")
	private String reason;

	@JsonProperty("reasonCode")
	private ErrorReasonCode reasonCode;

}
