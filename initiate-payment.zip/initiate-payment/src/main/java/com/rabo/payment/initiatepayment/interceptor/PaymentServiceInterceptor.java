package com.rabo.payment.initiatepayment.interceptor;

import java.io.ByteArrayInputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.rabo.payment.initiatepayment.constants.PaymentConstant;
import com.rabo.payment.initiatepayment.exception.PaymentServiceException;
import com.rabo.payment.initiatepayment.model.ErrorReasonCode;

@Component
public class PaymentServiceInterceptor implements HandlerInterceptor {

	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(this.getClass());

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		String methodName = "preHandle";
		LOGGER.info(this.getClass() + "::" + methodName);

		verifyIncomingCertificateSignatue(request);
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {

		String methodName = "postHandle";
		LOGGER.debug(this.getClass() + "::" + methodName);

	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception exception) throws Exception {

		String methodName = "postHandle";
		LOGGER.info(this.getClass() + "::" + methodName + PaymentConstant.AFTER_COMPLETION_MESSAGE);

	}

	/**
	 * This method is to validate unknown certificates and verify the
	 * X509Certificate using the SHA256WithRSA
	 * 
	 * @param request
	 * @throws Exception
	 */
	public void verifyIncomingCertificateSignatue(HttpServletRequest request) throws Exception {

		String methodName = "verifyIncomingCertificateSignatue";
		LOGGER.info(this.getClass() + "::" + methodName);

		X509Certificate x509Certificate = getUserCertificate(request);

		try {

			if (!x509Certificate.getSubjectDN().getName().startsWith("Sandbox-TPP")) {
				throw new PaymentServiceException(ErrorReasonCode.UNKNOWN_CERTIFICATE.toString());

			}

			Signature signature = Signature.getInstance(PaymentConstant.SIGNING_ALGORITHM);
			signature.initVerify(x509Certificate.getPublicKey());

			if (signature.verify(x509Certificate.getSignature())) {
				LOGGER.info(this.getClass() + "::" + methodName + "::" + PaymentConstant.CERTIFICATES_VERIFIED_MESSAGE);
			} else {
				LOGGER.info(
						this.getClass() + "::" + methodName + "::" + PaymentConstant.CERTIFICATES_NOT_VERIFIED_MESSAGE);
				throw new PaymentServiceException(ErrorReasonCode.INVALID_SIGNATURE.toString());
			}

		} catch (NoSuchAlgorithmException e) {

			LOGGER.info(this.getClass() + "::" + methodName + "::" + PaymentConstant.NO_SUCH_ALGORITHM_MESSAGE);
			throw new PaymentServiceException(ErrorReasonCode.INVALID_SIGNATURE.toString());
		} catch (InvalidKeyException e) {
			LOGGER.info(this.getClass() + "::" + methodName + "::" + PaymentConstant.INVALIDKEY_MESSAGE);
			throw new PaymentServiceException(ErrorReasonCode.INVALID_SIGNATURE.toString());
		} catch (SignatureException e) {
			LOGGER.info(this.getClass() + "::" + methodName + "::" + PaymentConstant.INVALID_SIGNATURE_MESSAGE);
			throw new PaymentServiceException(ErrorReasonCode.INVALID_SIGNATURE.toString());
		}
	}

	/**
	 * This method to create X509Certificate based on the Signature-Certificate
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private X509Certificate getUserCertificate(HttpServletRequest request) throws Exception {
		String methodName = "getUserCertificate";
		LOGGER.info(this.getClass() + "::" + methodName);

		CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
		ByteArrayInputStream bytes = new ByteArrayInputStream(request.getHeader("Signature-Certificate").getBytes());
		return (X509Certificate) certFactory.generateCertificate(bytes);
	}

}
