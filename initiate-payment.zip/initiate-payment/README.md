Pre-requisite:

1) Spring Boot 2.3.1
2) Java 1.8
3) Maven
4) Lombak
5) springdoc-openapi-ui dependency for swagger


1) Start the spring boot application wiht "InitiatePaymentApplication.java"
2) Bean validation is done in "PayementExceptionHandler.java"
3) Certificates validation is done in "PaymentServiceInterceptor.java".
4) Signature validation is done in "PaymentInitiationServiceImpl.java".
5) All business logic is added in "PaymentInitiationServiceImpl.java".
6) All log level is added in logback.xml

